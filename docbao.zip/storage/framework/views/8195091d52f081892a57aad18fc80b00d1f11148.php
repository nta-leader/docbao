<?php echo $__env->make('functions.indanhmuc_rss', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e($urlAdmin); ?>/bower_components/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo e($urlAdmin); ?>/bower_components/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo e($urlAdmin); ?>/bower_components/Ionicons/css/ionicons.min.css">
    <link rel="stylesheet" href="<?php echo e($urlAdmin); ?>/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo e($urlAdmin); ?>/dist/css/AdminLTE.min.css">
    <link rel="stylesheet" href="<?php echo e($urlAdmin); ?>/dist/css/skins/_all-skins.min.css">
    <link rel="stylesheet"
    href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('name'); ?>
    Quản lý rss
<?php $__env->stopSection(); ?>
<?php $__env->startSection('msg'); ?>
    <?php if(Session::has('msg')): ?>
        <div class="alert alert-success alert-dismissible msg">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <i class="icon fa fa-check"></i><?php echo e(Session::get('msg')); ?>

        </div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
    <div class="alert alert-danger alert-dismissible msg">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p><i class="icon fa fa-ban"></i><?php echo e($error); ?></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<style>
    .ajax-load-qa {
        background: url("https://2.bp.blogspot.com/-K6t6oBc4jd0/WC1H9h6QBWI/AAAAAAAAAMU/A0C5q9w-mwkVQf_HlezvaJ0lftPP1u9jwCLcB/s1600/loading%2B%25283%2529.gif") no-repeat center center rgba(255,255,255,0.5);
        position: fixed;
        z-index: 100;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        display: none;
        z-index: 1000000000;
    }
    .center{
        text-align:center;
    }
    .list_rss{
        text-align: left;
    }
</style>
<div id="tb">
    <div id="ajax_loader" class="ajax-load-qa"></div>  
</div>
    <div id="row" class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header">
                    <h3 class="box-title" style="display: block;text-align: center;">
                        <?php if(isset($_GET['Page'])): ?>
                            <?php echo e(getenv("PAGE_ADMIN")); ?> tin tiếp theo
                        <?php else: ?>
                        <?php echo e(getenv("PAGE_ADMIN")); ?> tin mới nhât
                        <?php endif; ?>
                    </h3>
                    <h3 class="box-title">
                        <a onclick="them()" data-toggle="modal" data-target="#modal-default" class="btn btn-success btn-md" title="Thêm rss">Thêm rss</a>
                        <a data-toggle="modal" data-target="#modal-ds" class="btn btn-success btn-md" title="Danh sách" rss">Danh sách rss</a>
                        <div class="btn-group">
                            <button type="button" class="btn btn-success">Chọn rss</button>
                            <button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown">
                                <span class="caret"></span>
                                <span class="sr-only">Toggle Dropdown</span>
                            </button>
                            <ul class="dropdown-menu" role="menu">
                            <?php $__currentLoopData = $objRss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $rss_id=$item->rss_id;
                                $name=$item->link;
                            ?>
                                <li><a href="<?php echo e(route('admin.tintuc.rss',['id'=>$rss_id])); ?>"><?php echo e($name); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <?php if($id > 0): ?>
                        <a id="click" onclick="capnhat()" href="<?php echo e(route('admin.tintuc.rss.update',['id'=>$id])); ?>" class="btn btn-success btn-md" title="Cập nhật css">Cập nhật</a>
                        <?php endif; ?>
                    </h3>
                </div>
                <!-- /.box-header -->
                <form action="<?php echo e(route('admin.tintuc.rss.tintucdel',['id'=>'0'])); ?>">
                <div class="box-body">
                    <table id="example1" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Tên tin tức</th>
                                <th>Nguồn</th>
                                <th>Giới thiệu</th>                               
                                <th>Ngày tạo</th>
                                <th class="center">Hình ảnh</th>
                                <th class="center">Trạng thái</th>
                                <th class="center">Chức năng</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $objItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $objItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $id=$objItem->id;
                            $name=$objItem->name;
                            $link=$objItem->link;
                            $preview=$objItem->preview;
                            $date=$objItem->date;
                            $picture=$objItem->picture;
                            $active=$objItem->active;
                            $urlDel=route('admin.tintuc.rss.tintucdel',['tintuc_id'=>$id]);
                        ?>
                            <tr>
                                <td>
                                    <input type="checkbox" name="arId[]" value="<?php echo e($id); ?>">
                                    <span style="font-size: 18px;margin-left: 5px;"><?php echo e($id); ?><span>
                                </td>
                                <td style="width:15%;"><?php echo e($name); ?></td>
                                <td style="width:15%;"><?php echo e($link); ?></td>
                                <td style="width:30%;"><?php echo e($preview); ?></td>                              
                                <td><?php echo e($date); ?></td>
                                <td>
                                    <center>
                                        <img width="100px" src="/storage/app/files/<?php echo e($picture); ?>">
                                    </center>
                                </td>
                                <td id="active<?php echo e($id); ?>">
                                <?php if($active==0): ?>
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-success">Chọn danh mục</button>
                                        <button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown">
                                            <span class="caret"></span>
                                            <span class="sr-only">Toggle Dropdown</span>
                                        </button>
                                        <ul class="dropdown-menu" role="menu">
                                            <?php echo e(indanhmuc($objDanhmuccha,$objDanhmuccon,$id)); ?>

                                        </ul>
                                    </div>
                                <?php else: ?>
                                    <a class="btn btn-danger">Tin này đã có</a>
                                <?php endif; ?>
                                </td>
                                <td>
                                    <center>
                                        <a href="<?php echo e($urlDel); ?>" class="btn btn-danger"><i class="fa fa-pencil"></i> Xóa</a>
                                    </center>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <button type="submit" onclick="return confirm('Bạn thực sự muốn xóa các bản ghi đã chọn?')" class="btn btn-danger">Xóa các tin đã chọn</a>
                </div>
                </form>
                <!-- /.box-body -->
            </div>
            <!-- /.box -->
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal'); ?>
<style>
    .border_radius{
        border-radius:5px;
    }
    .msg_modal{
        margin: 5px 0px -15px 0px;
        padding: 10px 33px 10px 10px;
    }
</style>
<div class="modal fade" id="modal-default" style="display: none;">
    <div class="modal-dialog">
    <div class="modal-content border_radius">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×</span>
            </button>
            <h3 class="modal-title" style="color:#00a65a;" id="name">Thêm rss</h3>
        </div>
        <div class="modal-body" id="modal-body">
            <form action="<?php echo e(route('admin.tintuc.rss.add')); ?>" method="POST" >
            <?php echo e(csrf_field()); ?>

                <div class="input-group">
                    <div class="input-group-btn">
                        <button type="button" class="btn btn-primary btn-flat">Link rss</button>
                    </div>
                    <input id="link" name="link" type="text" value="<?php echo e(old('link')); ?>" class="form-control" placeholder="Nhập link !">
                    <span class="input-group-btn" id="button">
                        <button type="submit"  class="btn btn-success btn-flat">Thêm</button>
                    </span>
                </div>
            </form>
        </div>
        <div class="modal-footer center">
            <button type="button" class="btn btn-default" data-dismiss="modal">Thoát</button>
        </div>
    </div>
    <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>

<div class="modal fade" id="modal-ds" style="display: none;">
    <div class="modal-dialog">
    <div class="modal-content border_radius">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×</span>
            </button>
            <h3 class="modal-title" style="color:#00a65a;" id="name">Danh sách rss</h3>
        </div>
        <div class="modal-body" id="modal-body">
        <?php $__currentLoopData = $objRss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $rss_id=$item->rss_id;
            $name=$item->link;
        ?>
            <div class="input-group">
                <div class="input-group-btn">
                    <button type="button" class="btn btn-primary btn-flat">Link rss</button>
                </div>
                <input readonly id="link" type="text" value="<?php echo e($name); ?>" class="form-control" placeholder="Nhập link !">
                <span class="input-group-btn" id="button">
                    <a href="<?php echo e(route('admin.tintuc.rss.del',['id'=>$rss_id])); ?>" onclick="return confirm('Bạn thực sự muốn xóa không ?')" class="btn btn-danger btn-flat">Xóa</a>
                </span>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="modal-footer center">
            <button type="button" class="btn btn-default" data-dismiss="modal">Thoát</button>
        </div>
    </div>
    <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<!-- jQuery 3 -->
<script src="<?php echo e($urlAdmin); ?>/bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="<?php echo e($urlAdmin); ?>/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- DataTables -->
<script src="<?php echo e($urlAdmin); ?>/bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?php echo e($urlAdmin); ?>/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<!-- SlimScroll -->
<script src="<?php echo e($urlAdmin); ?>/bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="<?php echo e($urlAdmin); ?>/bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo e($urlAdmin); ?>/dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo e($urlAdmin); ?>/dist/js/demo.js"></script>
<!-- page script -->
<script>
  $(function () {
    $('#example1').DataTable()
    $('#example2').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : false,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false
    })
  })
</script>
<script>
    $('#click').click(function(){   
        $('#ajax_loader').css( 'display', 'block' );
            setTimeout(function(){
            $('#ajax_loader').css( 'display', 'none' );
        }, 20000);        
    });
    function active(tintuc_rss_id,danhmuc_id,tendanhmuc){
        swal({   
            title: "Bạn có muốn thêm tin tức này vào danh mục ''"+tendanhmuc+"'' không ?",
            type: "warning",   
            showCancelButton: true,   
            confirmButtonColor: "#DD6B55",   
            confirmButtonText: "OK",   
            cancelButtonText: "Hủy",   
            closeOnConfirm: false,   
            }, 
            function(isConfirm){   
                if (isConfirm) {   
                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        }
                    });
                    $.ajax({
                        url: '<?php echo e(route('admin.tintuc.rss.move_tintuc')); ?>',
                        type: 'post',
                        cache: false,
                        data: {
                            tintuc_rss_id:tintuc_rss_id,
                            danhmuc_id:danhmuc_id
                        },
                        success: function(data){
                            $("#active"+tintuc_rss_id).html(data);
                            swal("Thêm thành công !","","success");
                        },
                        error: function (){
                            swal("Có lỗi xảy ra !","","error");
                        }
                    });
                }
            }
        );
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>