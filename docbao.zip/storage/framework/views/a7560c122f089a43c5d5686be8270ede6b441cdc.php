<center>
<?php if($req->active==0): ?>
    <a onclick="active('1','<?php echo e($req->tintuc_id); ?>')" class="btn btn-primary">Hiện thị</a>
<?php else: ?>
    <a onclick="active('0','<?php echo e($req->tintuc_id); ?>')" class="btn btn-danger">Đã ẩn</a>
<?php endif; ?>
</center>