<div class="alert alert-danger alert-dismissible msg_modal">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
    <i class="icon fa fa-ban"></i>Tên danh mục đã được sử dụng
</div>