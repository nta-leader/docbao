<?php
function indanhmuc($danhmuccha,$danhmuccon,$danhmuc_id=0){
    foreach($danhmuccha as $cha){
?>     
        <option <?php if( old('danhmuc_id') == $cha->danhmuc_id || $danhmuc_id == $cha->danhmuc_id ): ?> selected <?php endif; ?> value="<?php echo e($cha->danhmuc_id); ?>"><?php echo e($cha->tendanhmuc); ?></option>
<?php
        foreach($danhmuccon as $con){
            if($cha->danhmuc_id==$con->parent_id){
?>
                <option <?php if( old('danhmuc_id') == $con->danhmuc_id || $danhmuc_id == $con->danhmuc_id ): ?> selected <?php endif; ?>  value="<?php echo e($con->danhmuc_id); ?>">--| <?php echo e($con->tendanhmuc); ?></option>
<?php
            }
        }
    }
}