<?php echo $__env->make('templates.admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<style>
    .msg{
        width:98%;
        margin-left:1%;
        margin-top:15px;
        margin-bottom:0px;
    }
</style>
<!-- Left side column. contains the logo and sidebar -->
        <aside class="main-sidebar">
            <!-- sidebar: style can be found in sidebar.less -->
            <?php echo $__env->make('templates.admin.left_bar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!-- /.sidebar -->
        </aside>
        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <section class="content-header">
                <h1 style="color:red;">
                    <?php echo $__env->yieldContent('name'); ?>
                </h1>
                <ol class="breadcrumb">
                    <li><a href="#"><i class="fa fa-dashboard"></i> Level</a>
                    </li>
                    <li class="active">Here</li>
                </ol>
            </section>
            <!-- Main content -->
            <?php echo $__env->yieldContent('msg'); ?>
            <section class="content container-fluid">
                <!--------------------------| Your Page Content Here |-------------------------->
                <?php echo $__env->yieldContent('content'); ?>
            </section>
            <!-- /.content -->
        </div>
        <!-- /.content-wrapper -->
        <?php echo $__env->yieldContent('modal'); ?>
        <!-- Main Footer -->
<?php echo $__env->make('templates.admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>