<?php
function indanhmuc($danhmuccha,$danhmuccon,$tintuc_rss_id){
    foreach($danhmuccha as $cha){
?>     
        <li  class="btn btn-block btn-primary btn-sm list_rss" onclick="active('<?php echo e($tintuc_rss_id); ?>','<?php echo e($cha->danhmuc_id); ?>','<?php echo e($cha->tendanhmuc); ?>')"><?php echo e($cha->tendanhmuc); ?></li>
<?php
        foreach($danhmuccon as $con){
            if($cha->danhmuc_id==$con->parent_id){
?>
                <li class="btn btn-block btn-primary btn-sm list_rss" onclick="active('<?php echo e($tintuc_rss_id); ?>','<?php echo e($cha->danhmuc_id); ?>','<?php echo e($cha->tendanhmuc); ?>')">--| <?php echo e($con->tendanhmuc); ?></li>
<?php
            }
        }
    }
}