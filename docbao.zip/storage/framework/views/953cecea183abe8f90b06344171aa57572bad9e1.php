<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e($urlAdmin); ?>/bower_components/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo e($urlAdmin); ?>/bower_components/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo e($urlAdmin); ?>/bower_components/Ionicons/css/ionicons.min.css">
    <link rel="stylesheet" href="<?php echo e($urlAdmin); ?>/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo e($urlAdmin); ?>/dist/css/AdminLTE.min.css">
    <link rel="stylesheet" href="<?php echo e($urlAdmin); ?>/dist/css/skins/_all-skins.min.css">
    <link rel="stylesheet"
    href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('name'); ?>
    Quản lý tin tức
<?php $__env->stopSection(); ?>
<?php $__env->startSection('msg'); ?>
    <?php if(Session::has('msg')): ?>
        <div class="alert alert-success alert-dismissible msg">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <i class="icon fa fa-check"></i><?php echo e(Session::get('msg')); ?>

        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<style>
    .center{
        text-align:center;
    }
</style>
    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header">
                    <h3 class="box-title" style="display: block;text-align: center;">
                        <?php if(isset($_GET['Page'])): ?>
                            <?php echo e(getenv("PAGE_ADMIN")); ?> tin tiếp theo
                        <?php else: ?>
                        <?php echo e(getenv("PAGE_ADMIN")); ?> tin mới nhât
                        <?php endif; ?>
                    </h3>
                    <h3 class="box-title">
                        <a href="<?php echo e(route("admin.tintuc.add")); ?>" class="btn btn-success btn-md" title="Thêm danh mục cha">Thêm</a>
                        <a href="<?php echo e(route("admin.tintuc.rss",["id"=>"0"])); ?>" class="btn btn-success btn-md" title="Thêm danh mục cha">RSS</a>
                    </h3>
                </div>
                <!-- /.box-header -->
                <form action="<?php echo e(route('admin.tintuc.del',['tintuc_id'=>'0'])); ?>">
                <div class="box-body">
                    <table id="example1" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Tên tin tức</th>
                                <th>Lượt xem</th>
                                <th>Danh mục</th>
                                <th>Giới thiệu</th>                               
                                <th>Ngày tạo</th>
                                <th>Nguồn</th>
                                <th class="center">Hình ảnh</th>
                                <th class="center">Trạng thái</th>
                                <th class="center">Chức năng</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $objItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $objItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $id=$objItem->tintuc_id;
                            $name=$objItem->tentintuc;
                            $luotxem=$objItem->luotxem;
                            $danhmuc=$objItem->tendanhmuc;
                            $gioithieu=$objItem->gioithieu;
                            $date=$objItem->ngaytao;
                            $nguon=$objItem->nguon;
                            $picture=$objItem->hinhanh;
                            $active=$objItem->active;
                            $urlEdit=route('admin.tintuc.edit',['tintuc_id'=>$id]);
                            $urlDel=route('admin.tintuc.del',['tintuc_id'=>$id]);
                        ?>
                            <tr>
                                <td>
                                    <input type="checkbox" name="arId[]" value="<?php echo e($id); ?>">
                                    <span style="font-size: 18px;margin-left: 5px;"><?php echo e($id); ?><span>
                                </td>
                                <td style="width:20%;"><?php echo e($name); ?></td>
                                <td><?php echo e($luotxem); ?></td>
                                <td><?php echo e($danhmuc); ?></td>
                                <td style="width:20%;"><?php echo e($gioithieu); ?></td>                              
                                <td><?php echo e($date); ?></td>
                                <td><?php echo e($nguon); ?></td>
                                <td>
                                    <center>
                                        <img width="100px" src="/storage/app/files/<?php echo e($picture); ?>">
                                    </center>
                                </td>
                                <td id="active<?php echo e($id); ?>">
                                    <center>
                                    <?php if($active==1): ?>
                                        <a onclick="active('1','<?php echo e($id); ?>')" class="btn btn-primary">Hiện thị</a>
                                    <?php else: ?>
                                        <a onclick="active('0','<?php echo e($id); ?>')" class="btn btn-danger">Đã ẩn</a>
                                    <?php endif; ?>
                                    </center>
                                </td>
                                <td>
                                    <center>
                                        <a href="<?php echo e($urlEdit); ?>" class="btn btn-primary"><i class="fa fa-edit"></i> Sửa</a>
                                        <a onclick="del('<?php echo e($urlDel); ?>','')" class="btn btn-danger"><i class="fa fa-pencil"></i> Xóa</a>
                                    </center>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <button type="submit" onclick="return confirm('Bạn thực sự muốn xóa các bản ghi đã chọn?')" class="btn btn-danger">Xóa các tin đã chọn</a>
                </div>
                </form>
                <!-- /.box-body -->
            </div>
            <!-- /.box -->
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<!-- jQuery 3 -->
<script src="<?php echo e($urlAdmin); ?>/bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="<?php echo e($urlAdmin); ?>/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- DataTables -->
<script src="<?php echo e($urlAdmin); ?>/bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?php echo e($urlAdmin); ?>/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<!-- SlimScroll -->
<script src="<?php echo e($urlAdmin); ?>/bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="<?php echo e($urlAdmin); ?>/bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo e($urlAdmin); ?>/dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo e($urlAdmin); ?>/dist/js/demo.js"></script>
<!-- page script -->
<script>
  $(function () {
    $('#example1').DataTable()
    $('#example2').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : false,
      'ordering'    : true,
      'info'        : true,
      'autoWidth'   : false
    })
  })
</script>
   <script>
        function active(active,tintuc_id){
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                url: '<?php echo e(route('admin.tintuc.active')); ?>',
                type: 'post',
                cache: false,
                data: {
                    active:active,
                    tintuc_id:tintuc_id
                },
                success: function(data){
                    $('#active'+tintuc_id).html(data);
                },
                error: function (){
                    swal("Có lỗi xảy ra !","","error");
                }
            });
        }
        function del(url,title){
            swal({   
                title: "Bạn có muốn xóa "+title+" tin tức này không ?",
                type: "warning",   
                showCancelButton: true,   
                confirmButtonColor: "#DD6B55",   
                confirmButtonText: "OK",   
                cancelButtonText: "Hủy",   
                closeOnConfirm: false,   
                }, 
                function(isConfirm){   
                    if (isConfirm) {   
                        window.location.href=url;   
                    }
                }
            );
        }
   </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>