<?php echo $__env->make('functions.indanhmuc', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e($urlAdmin); ?>/bower_components/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo e($urlAdmin); ?>/bower_components/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo e($urlAdmin); ?>/bower_components/Ionicons/css/ionicons.min.css">
    <link rel="stylesheet" href="<?php echo e($urlAdmin); ?>/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo e($urlAdmin); ?>/dist/css/AdminLTE.min.css">
    <link rel="stylesheet" href="<?php echo e($urlAdmin); ?>/dist/css/skins/_all-skins.min.css">
    <link rel="stylesheet"href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
    <style>
        .loi{
            padding: 1px 7px;
            margin-bottom: 2px;
        }
    </style>
<?php $__env->stopSection(); ?>
<!-- Phan title -->
<?php $__env->startSection('name'); ?>
    Thêm tin tức
<?php $__env->stopSection(); ?>
<!-- Phan thong bao -->
<?php $__env->startSection('msg'); ?>
    <?php if(Session::has('msg')): ?>
        <div class="alert alert-success alert-dismissible msg">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <i class="icon fa fa-check"></i><?php echo e(Session::get('msg')); ?>

        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<!-- Phan noi dung chinh -->
<?php $__env->startSection('content'); ?>
<?php if($errors->any()): ?>
    <?php $loi=$errors->toArray(); ?>
<?php endif; ?>
<div class="box box-warning">
    <!-- /.box-header -->
    <div class="box-body">
        <form action="<?php echo e(route("admin.tintuc.add")); ?>" method="POST" enctype="multipart/form-data" role="form" style="margin: 30px 5% 30px 5%;">
            <!-- Ten tin tuc -->
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <label>Tên tin tức</label>
                <?php if($errors->has('tentintuc')): ?>
                <div class="alert alert-danger alert-dismissible loi">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php $__currentLoopData = $loi['tentintuc']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p><i class="icon fa fa-ban"></i><?php echo e($error); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endif; ?>
                <input type="text" name="tentintuc" value="<?php echo e(old('tentintuc')); ?>" class="form-control" placeholder="Nhập tên tin tức ...">
            </div>
            <!-- Ten danh muc -->
            <div class="form-group">
                <label>Danh mục</label>
                <?php if($errors->has('danhmuc_id')): ?>
                <div class="alert alert-danger alert-dismissible loi">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php $__currentLoopData = $loi['danhmuc_id']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p><i class="icon fa fa-ban"></i><?php echo e($error); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endif; ?>
                <select name="danhmuc_id" class="form-control">
                    <option value="">--Chọn danh mục--</option>
                    <?php echo e(indanhmuc($objDanhmuccha,$objDanhmuccon)); ?>

                </select>
            </div>
            <!-- hinh anh -->
            <div class="form-group">
                <label>Hình ảnh</label>
                <?php if($errors->has('hinhanh')): ?>
                <div class="alert alert-danger alert-dismissible loi">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php $__currentLoopData = $loi['hinhanh']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p><i class="icon fa fa-ban"></i><?php echo e($error); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endif; ?>
                <input type="file" name="hinhanh"  value="<?php echo e(old('hinhanh')); ?>" class="form-control">
            </div>
            <!-- Gioi thieu -->
            <div class="form-group">
                <label>Giới thiệu</label>
                <?php if($errors->has('gioithieu')): ?>
                <div class="alert alert-danger alert-dismissible loi">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php $__currentLoopData = $loi['gioithieu']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p><i class="icon fa fa-ban"></i><?php echo e($error); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endif; ?>
                <textarea name="gioithieu" class="form-control" rows="3" placeholder="Nhập giới thiệu tin tức..."><?php echo e(old('gioithieu')); ?></textarea>
            </div>
            <!-- Chi tiet -->
            <div class="form-group">
                <label>Chi tiết</label>
                <?php if($errors->has('chitiet')): ?>
                <div class="alert alert-danger alert-dismissible loi">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php $__currentLoopData = $loi['chitiet']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p><i class="icon fa fa-ban"></i><?php echo e($error); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endif; ?>
                <textarea name="chitiet" class="form-control ckeditor" rows="3" placeholder="Nhập chi tiết tin tức...">
                <?php echo e(old('chitiet')); ?>

                </textarea>
            </div>
            <!-- active -->
            <div class="form-group">
                <?php if($errors->has('active')): ?>
                <div class="alert alert-danger alert-dismissible loi">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php $__currentLoopData = $loi['active']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p><i class="icon fa fa-ban"></i><?php echo e($error); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endif; ?>
                <label>
                    <input type="radio" name="active" id="optionsRadios1" value="0" <?php if(old("active")=="0"): ?>) checked <?php endif; ?> >
                    Ẩn
                </label>
                <label style="margin-left:25px;">
                    <input type="radio" name="active" id="optionsRadios2" value="1" <?php if(old("active")=="1"): ?>) checked <?php endif; ?> >
                    Hiện
                </label>
            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-success btn-flat">Thêm</button>
            </div>
        </form>
    </div>
    <!-- /.box-body -->
</div>
<?php $__env->stopSection(); ?>
<!-- Phan modal -->
<?php $__env->startSection('modal'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<!-- jQuery 3 -->
<script src="<?php echo e($urlAdmin); ?>/bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="<?php echo e($urlAdmin); ?>/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- DataTables -->
<script src="<?php echo e($urlAdmin); ?>/bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="<?php echo e($urlAdmin); ?>/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<!-- SlimScroll -->
<script src="<?php echo e($urlAdmin); ?>/bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="<?php echo e($urlAdmin); ?>/bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo e($urlAdmin); ?>/dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo e($urlAdmin); ?>/dist/js/demo.js"></script>

<script src="<?php echo e($urlAdmin); ?>/bower_components/ckeditor/ckeditor.js"></script>
<!-- page script -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>