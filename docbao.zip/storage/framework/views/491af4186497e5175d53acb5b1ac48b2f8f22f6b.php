<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e($urlAdmin); ?>/bower_components/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo e($urlAdmin); ?>/bower_components/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo e($urlAdmin); ?>/bower_components/Ionicons/css/ionicons.min.css">
    <link rel="stylesheet" href="<?php echo e($urlAdmin); ?>/dist/css/AdminLTE.min.css">
    <link rel="stylesheet" href="<?php echo e($urlAdmin); ?>/dist/css/skins/skin-blue.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
    <link rel="stylesheet" type="text/css" href="<?php echo e($urlAdmin); ?>/sweetalert.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('name'); ?>
    Chào mừng bạn đến với trang quản trị
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    Theanh
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e($urlAdmin); ?>/bower_components/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap 3.3.7 -->
    <script src="<?php echo e($urlAdmin); ?>/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- AdminLTE App -->
    <script src="<?php echo e($urlAdmin); ?>/dist/js/adminlte.min.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>