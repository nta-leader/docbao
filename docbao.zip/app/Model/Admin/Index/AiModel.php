<?php

namespace App\Model\Admin\Index;

use Illuminate\Database\Eloquent\Model;

class AiModel extends Model
{
    //
}
